package com.company;

public class UserImpl extends AbstractUser{

    /** This is UserImpl constructor */
    public UserImpl(boolean isAdmin, String username) {
        super(isAdmin, username);
    }

}
